const express = require('express');
const app = express();
const PORT = 5000;


let users = [
    { id: 1, name: 'Alice' },
    { id: 2, name: 'Bob' },
    { id: 3, name: 'Charlie' },
    { id: 4, name: 'Diana' },
    { id: 5, name: 'Eva' },
    { id: 6, name: 'Frank' },
    { id: 7, name: 'Gina' },
    { id: 8, name: 'Henry' },
    { id: 9, name: 'Iris' },
    { id: 10, name: 'Jack' }
];

app.use(express.json());

app.get('/users', (req, res) => {
    res.json(users);
});


app.get('/users/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const user = users.find(user => user.id === id);
    if (!user) {
        res.status(404).json({ message: 'Usuário não encontrado' });
    } else {
        res.json(user);
    }
});


app.post('/users', (req, res) => {
    const user = req.body;
    users.push(user);
    res.status(201).json(user);
});


app.put('/users/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const updateUser = req.body;
    users = users.map(user => user.id === id ? { ...user, ...updateUser } : user);
    res.json(users.find(user => user.id === id));
});


app.delete('/users/:id', (req, res) => {
    const id = parseInt(req.params.id);
    users = users.filter(user => user.id !== id);
    res.json({ message: 'Usuário removido com sucesso' });
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
